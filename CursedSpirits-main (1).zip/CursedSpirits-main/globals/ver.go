package globals

const (
	VERSION = "1.0.0"
)